# Whitedot Cryptocurrency
See the GitHub repository: https://github.com/SeafoodStudios/Whitedot